function abrirMenu(){
    document.getElementById("menu-Oculto").style.width="400px";
    document.getElementById("principal").style.marginLeft="0px";
}
function fecharMenu(){
    document.getElementById("menu-Oculto").style.width="0vw";
    document.getElementById("principal").style.marginLeft="0vw";
}