<?php
header('location: Bibliotecario/Login/');
?>